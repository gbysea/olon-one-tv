Place the 12 quark icon PNGs here (120x120):

- up-UP-olon-120.png
- up-HOVER-olon-120.png
- down-UP-olon-120.png
- down-HOVER-olon-120.png
- charm-UP-olon-120.png
- charm-HOVER-olon-120.png
- strange-UP-olon-120.png
- strange-HOVER-olon-120.png
- top-UP-olon-120.png
- top-HOVER-olon-120.png
- bottom-UP-olon-120.png
- bottom-HOVER-olon-120.png

Do NOT commit real keys or private material.
